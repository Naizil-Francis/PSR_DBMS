<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "login_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to authenticate user
function authenticateUser($username, $password, $usertype, $conn) {
    // Sanitize input
    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);
    $usertype = $conn->real_escape_string($usertype);
    
    // Prepare SQL statement with prepared statement
    $sql = "SELECT * FROM credentials WHERE username=? AND password=? AND login_type=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $password, $usertype);
    
    // Execute SQL statement
    $stmt->execute();
    
    // Check if user exists
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        return true; // User authenticated successfully
    } else {
        return false; // Authentication failed
    }
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username = $_POST["username"];
    $password = $_POST["password"];
    $usertype = $_POST["login_type"]; // Assuming the login type is passed as "login_type" parameter
    
    // Authenticate user
    if (authenticateUser($username, $password, $usertype, $conn)) {
        // Redirect based on user type
        echo "<script>";
        echo "if ('$usertype' === 'user') {";
        echo "  alert('Logged in as User');"; // Alert for user login
        echo "  window.location.href = '../USER/MAIN.php?username=$username';";
        echo "} else if ('$usertype' === 'employee') {";
        echo "  alert('Logged in as Employee');"; // Alert for employee login
        echo "  window.location.href = '../EMPLOYEE/MAIN.php?username=$username';";
        echo "}";
        echo "</script>";
    } else {
        echo "<script>alert('Invalid credentials. Please try again.');</script>"; // JavaScript alert for invalid credentials
        echo "<script>window.location.href = 'START.php';</script>";
    }
}

// Close connection
$conn->close();
?>
