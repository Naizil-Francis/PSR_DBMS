<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$database = "login_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create tables if not exist
$sql_queries = array(
    // Create PANCHAYAT table
    "CREATE TABLE IF NOT EXISTS PANCHAYATH (
      VILLAGE_CODE VARCHAR(10) UNIQUE PRIMARY KEY,
      PINCODE INT,
      VILLAGE_ADDRESS VARCHAR(30),
      VILLAGE_NAME VARCHAR(20)
    )",
    // Create USER table
    "CREATE TABLE IF NOT EXISTS USER (
      AADHAR_NO INT UNIQUE PRIMARY KEY,
      NAME VARCHAR(20),
      CARD_NUMBER VARCHAR(10),
      OCCUPATION VARCHAR(20),
      CONTACT INT,
      EMAIL VARCHAR(30),
      VILLAGE_CODE VARCHAR(10),
      ADDRESS VARCHAR(30),
      FOREIGN KEY (VILLAGE_CODE) REFERENCES PANCHAYATH(VILLAGE_CODE) on DELETE CASCADE on update CASCADE
)",
    // Create EMPLOYEE table
    "CREATE TABLE IF NOT EXISTS EMPLOYEE (
      EMPLOYEE_ID VARCHAR(10) UNIQUE PRIMARY KEY,
      EMPLOYEE_NAME VARCHAR(20),
      CONTACT INT,
      EMAIL VARCHAR(30),
      VILLAGE_CODE VARCHAR(10),
      FOREIGN KEY(VILLAGE_CODE) REFERENCES PANCHAYATH(VILLAGE_CODE) on DELETE CASCADE on update CASCADE
    )",
    // Create SCHEME table
    "CREATE TABLE IF NOT EXISTS SCHEME (
      SCHEME_ID VARCHAR(10) UNIQUE PRIMARY KEY,
      SCHEME_NAME VARCHAR(30),
      DOMAIN VARCHAR(20),
      DESCRIPTION VARCHAR(50),
      EMPLOYEE_ID VARCHAR(10),
      FOREIGN KEY(EMPLOYEE_ID) REFERENCES EMPLOYEE(EMPLOYEE_ID) on DELETE CASCADE on update CASCADE
    )",
    // Create OPTIONS table
    "CREATE TABLE IF NOT EXISTS OPTIONS (
      SCHEME_ID VARCHAR(10) UNIQUE,
      VILLAGE_CODE VARCHAR(10),
      PRIMARY KEY(SCHEME_ID, VILLAGE_CODE),
      FOREIGN KEY(SCHEME_ID) REFERENCES SCHEME(SCHEME_ID) on DELETE CASCADE on update CASCADE,
      FOREIGN KEY(VILLAGE_CODE) REFERENCES PANCHAYATH(VILLAGE_CODE) on DELETE CASCADE on update CASCADE
    )",
    // Create REGISTER table
    "CREATE TABLE IF NOT EXISTS REGISTER (
      SCHEME_ID VARCHAR(10),
      AADHAR_NO INT,
      APPLICATION_NO int UNIQUE,
      STATUS VARCHAR(20),
      DATE DATE,
      PRIMARY KEY(APPLICATION_NO),
      FOREIGN KEY(SCHEME_ID) REFERENCES OPTIONS(SCHEME_ID) on DELETE CASCADE on update CASCADE,
      FOREIGN KEY(AADHAR_NO) REFERENCES USER(AADHAR_NO) on DELETE CASCADE on update CASCADE
    )",
    // Create CREDENTIALS table
    "CREATE TABLE IF NOT EXISTS CREDENTIALS (
      USERNAME VARCHAR(50) PRIMARY KEY,
      PASSWORD VARCHAR(255) NOT NULL,
      AADHAR_NO INT,
      EMPLOYEE_ID VARCHAR(10),
      LOGIN_TYPE VARCHAR(12),
      FOREIGN KEY (AADHAR_NO) REFERENCES USER(AADHAR_NO) on DELETE CASCADE on update CASCADE,
      FOREIGN KEY (EMPLOYEE_ID) REFERENCES EMPLOYEE(EMPLOYEE_ID) on DELETE CASCADE on update CASCADE,
      CONSTRAINT CK_CREDENTIALS_TYPE CHECK (
        (AADHAR_NO IS NOT NULL AND EMPLOYEE_ID IS NULL) OR
        (EMPLOYEE_ID IS NOT NULL AND AADHAR_NO IS NULL)
      )
    )"
);

// Execute SQL queries to create tables
foreach ($sql_queries as $sql) {
    if ($conn->query($sql) === FALSE) {
        die("Error creating table: " . $conn->error);
    }
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="container">
  <div class="row justify-content-center login-container">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          Login
        </div>
        <div class="card-body">
          <form method="post" action="LOGIN.php"> <!-- Set action to login.php -->
            <div class="form-group">
              <label for="username">Username</label>
              <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            </div>
            <div class="form-group">
              <label for="login_type">Choose login type:</label>
              <select class="form-control" id="login_type" name="login_type">
                <option value="user">User</option>
                <option value="employee">Employee</option>
              </select>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
            <div class="text-center mt-3">
              <a href="OPTON.php" class="small-link">Create New Account</a> | <a href="#" class="small-link">Forgot Password?</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
