<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "login_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to register employee
function registerEmployee($employee_id, $employee_name, $contact, $mail, $village_code, $username, $password, $conn) {
    // Sanitize input
    
    $employee_id = $conn->real_escape_string($employee_id);
    $employee_name = $conn->real_escape_string($employee_name);
    $contact = $conn->real_escape_string($contact);
    $mail = $conn->real_escape_string($mail);
    $village_code = $conn->real_escape_string($village_code);
    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);

    // Check if employee ID is not empty
    if (empty($employee_id)) {
        return false; // Employee ID is empty
    }

    // Begin transaction
    $conn->begin_transaction();

    // Insert into users table
    $sql_users = "INSERT INTO employee (employee_id, employee_name, contact, email, village_code)
                  VALUES ('$employee_id', '$employee_name', '$contact', '$mail', '$village_code')";
    $result_users = $conn->query($sql_users);

    // Insert into credentials table
    $sql_credentials = "INSERT INTO credentials (username, password, aadhar_no, EMPLOYEE_ID,login_type)
                        VALUES ('$username', '$password',null,'$employee_id','employee')";
    $result_credentials = $conn->query($sql_credentials);

    // Commit transaction if both queries succeed, otherwise rollback
    if ($result_users && $result_credentials) {
        $conn->commit();
        return true; // User registered successfully
    } else {
        $conn->rollback();
        return false; // Registration failed
    }
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
  
    $employee_id = $_POST["employee_id"];
    $employee_name = $_POST["employee_name"];
    $contact = $_POST["contact"];
    $mail = $_POST["mail"];
    $village_code = $_POST["village_code"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Register user if Employee ID is not empty
    if (!empty($employee_id)) {
        // Attempt registration
        if (registerEmployee($employee_id, $employee_name, $contact, $mail, $village_code, $username, $password, $conn)) {
            $registration_status = "Employee registered successfully!";
        } else {
            $registration_status = "Error: Registration failed!";
        }
    } else {
        $registration_status = "Error: Employee ID cannot be empty!";
    }
}

// Check if registration was successful and redirect
if ($registration_status === "Employee registered successfully!") {
    echo "<script>
            alert('Employee registered successfully!');
            window.location.href = '../BEGIN/START.php';
          </script>";
}
// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Registration</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="container login-container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Employee Registration
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="form-group">
                            <label for="employee_id">Employee ID:</label>
                            <input type="text" id="employee_id" name="employee_id" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="employee_name">Employee Name:</label>
                            <input type="text" id="employee_name" name="employee_name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="contact">Contact:</label>
                            <input type="text" id="contact" name="contact" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="mail">Email:</label>
                            <input type="email" id="mail" name="mail" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="village_code">Village Code:</label>
                            <input type="text" id="village_code" name="village_code" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" id="username" name="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Register" class="btn btn-primary btn-block">
                        </div>
                    </form>
                    <div class="message"><?php echo isset($message) ? $message : ''; ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
