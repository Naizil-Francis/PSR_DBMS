<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "login_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to register user
function registerUser($conn, $name, $aadhaar, $address, $ration_card, $phone, $email, $occupation, $username, $password,$vcode) {
    // Sanitize input
    $name = $conn->real_escape_string($name);
    $aadhaar = $conn->real_escape_string($aadhaar);
    $address = $conn->real_escape_string($address);
    $ration_card = $conn->real_escape_string($ration_card);
    $phone = $conn->real_escape_string($phone);
    $email = $conn->real_escape_string($email);
    $occupation = $conn->real_escape_string($occupation);
    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);
    
    // Check if Aadhaar number is not empty
    if (empty($aadhaar)) {
        return "Error: Aadhaar number cannot be empty!";
    }

    // Begin transaction
    $conn->begin_transaction();

    // Insert into users table
    $sql_users = "INSERT INTO USER (NAME, AADHAR_NO, CARD_NUMBER, OCCUPATION, CONTACT, EMAIL, ADDRESS, VILLAGE_CODE)
                  VALUES ('$name', '$aadhaar', '$ration_card', '$occupation', '$phone', '$email', '$address','$vcode')";
    $result_users = $conn->query($sql_users);

    // Insert into credentials table
    $sql_credentials = "INSERT INTO CREDENTIALS (USERNAME, PASSWORD, AADHAR_NO, EMPLOYEE_ID, LOGIN_TYPE)
                        VALUES ('$username', '$password', '$aadhaar', null, 'user')";
    $result_credentials = $conn->query($sql_credentials);

    // Commit transaction if both queries succeed, otherwise rollback
    if ($result_users && $result_credentials) {
        $conn->commit();
        return "User registered successfully!";
    } else {
        $conn->rollback();
        return "Error: Registration failed!";
    }
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST["name"];
    $aadhaar = $_POST["aadhaar"];
    $address = $_POST["address"];
    $ration_card = $_POST["ration_card"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $occupation = $_POST["occupation"];
    $vcode = $_POST["village_code"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Attempt registration
    $registration_status = registerUser($conn, $name, $aadhaar, $address, $ration_card, $phone, $email, $occupation,$vcode, $username, $password);
    
    // Output registration status
    echo $registration_status;

    // If registration is successful, redirect to start page and display message
    if ($registration_status === "User registered successfully!") {
        echo "<script>
                alert('User registered successfully!');
                window.location.href = '../BEGIN/START.php';
              </script>";
    }
}

// Close connection
$conn->close();
?>
