<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "login_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$usernames = isset($_GET['username']) ? $_GET['username'] : "Guest";
$l = $usernames;
$aadhaar_info = ""; // Initialize Aadhaar info variable
$message = "";

// Function to logout
function logout() {
    echo "<script>alert('Logged out'); window.location.href = 'index.php';</script>";
}

// Query to fetch Aadhaar details based on username using prepared statement
$sql = "SELECT u.AADHAR_NO
        FROM USER u 
        INNER JOIN CREDENTIALS c ON u.AADHAR_NO = c.AADHAR_NO 
        WHERE c.USERNAME = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $usernames);
$stmt->execute();
$result = $stmt->get_result();

// Check if the query returned any result
if ($result->num_rows > 0) {
    // Fetch the Aadhaar info
    $row = $result->fetch_assoc();
    $aadhaar_info = $row['AADHAR_NO'];
} else {
    $message = "Username not found.";
}

// Close prepared statement
$stmt->close();

// Auto-generate application number (example: current timestamp)
$application_number = time(); // You can use any logic to generate a unique application number

// Get current date
$date_of_applying = date("Y-m-d");

// Default status
$status = "Yet to be submitted";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $scheme_id = ($_POST['scheme_id']);
    $status = $_POST['status'];

    // Insert application data into the database
    $sql_insert = "INSERT INTO REGISTER(SCHEME_ID,AADHAR_NO,APPLICATION_NO,STATUS,DATE) VALUES ('$scheme_id', '$aadhaar_info', '$application_number', '$status', '$date_of_applying')";
    $result_insert = $conn->query($sql_insert);
    

    if ($result_insert) {
        $message = "Application submitted successfully. Note down the application number: $application_number";
    } else {
        $message = "Error submitting application: " . $conn->error;
    }

    // Close prepared statement
    $stmt_insert->close();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Application</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f0faff; /* Very light blue background */
        }
        .navbar {
            background-color: #007bff !important; /* Blue navbar */
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">HOME</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="APPLY.php?username=<?php echo $usernames; ?>">New Application</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="EDIT.php?username=<?php echo $usernames; ?>">Edit Details</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="CHECK.php?username=<?php echo $usernames; ?>">My Applications</a>
            </li>
        </ul>
        <span class="navbar-text mr-3">
            Welcome, <?php echo $usernames; ?> <!-- Display the username -->
        </span>
        <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-danger my-2 my-sm-0" type="button" onclick="lO()">Logout</button>
        </form>
    </div>
</nav>
<div class="container mt-5">
    <h3 class="text-center">New Application</h3>
    <?php if (!empty($message)) : ?>
        <div class="alert alert-<?php echo $result_insert ? 'success' : 'danger'; ?>" role="alert">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="aadhaar">Aadhaar Number:</label>
            <input type="text" class="form-control" id="aadhaar" name="aadhaar" value="<?php echo $aadhaar_info; ?>" readonly>
        </div>   
        <div class="form-group">
            <label for="scheme_id">Scheme ID:</label>
            <input type="text" class="form-control" id="scheme_id" name="scheme_id" required>
        </div>
        <div class="form-group">
            <label for="application_number">Application Number:</label>
            <input type="text" class="form-control" id="application_number" name="application_number" value="<?php echo $application_number; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <input type="text" class="form-control" id="status" name="status" value="<?php echo $status; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="date_of_applying">Date of Applying:</label>
            <input type="date" class="form-control" id="date_of_applying" name="date_of_applying" value="<?php echo $date_of_applying; ?>" readonly>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    <p class="mt-3">Please note down the application number: <?php echo $application_number; ?></p>
</div>
<script>
  function logout() {
    alert("Logged out"); // Display message
    window.location.href = "index.php"; // Redirect to index.php
  }
</script>
</body>
</html>
